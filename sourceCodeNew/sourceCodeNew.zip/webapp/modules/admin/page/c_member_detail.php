<?php
/**
 * @copyright 2005-2008 OpenPNE Project
 * @license   http://www.php.net/license/3_01.txt PHP License 3.01
 */

// メンバー強制退会 確認画面
class admin_page_c_member_detail extends OpenPNE_Action
{
    function execute($requests)
    {

	if(isset($_GET['msg']) && $_GET['msg']){
		$this->set('msg', $_GET['msg']);
	}

        $v = array();

        $v['c_profile_list'] = db_member_c_profile_list4null();
	// 必要のないプロフィール削除
	$check_v = array();
	$line=0;
	foreach($v['c_profile_list'] as $ck=>$cv){
		if($cv['c_profile_id']!=9){
			$check_v[$line] = $v['c_profile_list'][$ck];
			$line++;
		}
	}
	$v['c_profile_list'] = $check_v;

        $v['c_member'] = db_member_c_member4c_member_id($requests['target_c_member_id'], true, true, 'private');
        $v['from'] = $requests['from'];
        $this->set($v);
	// ブラックリストデータ
	$sql = "select info from c_blacklist where c_member_id = ".$requests['target_c_member_id'];
	$info = db_get_all($sql);
	$this->set('info', isset($info[0]['info']) ? $info[0]['info']: null );

	// set list checkbox
	$sql = "select * from a_hall where flag=0 order by pulldown desc";
	$hall_list = db_get_all($sql, $db);

	if(!empty($hall_list)){
		foreach ($hall_list as $key => $halls) {			
			$hallLists[] = $halls['hall_id'];
		}
	}
	$hallLists = isset($hallLists) ? $hallLists : null;
	$this->set('hallLists',json_encode($hallLists));

	// 代理店データ
	$sql = "select * from a_agency where c_member_id = ".$requests['target_c_member_id'];
	$agency_data = db_get_all($sql);
	$this->set('agency_data', isset($agency_data[0]) ? $agency_data[0] : null);
	$agecyOld = empty($agency_data[0]['hall_list']) ? null : json_decode($agency_data[0]['hall_list'],true);
	$hall_lists = $hall_list;
	
	foreach ($hall_lists as $key => $value) {
		if(!empty($agecyOld)){
			if(array_key_exists($value['hall_id'],$agecyOld)){
				$hall_list[$key]['flagChecked'] = 1;
				$hall_list[$key]['pecentValue'] = $agecyOld[$value['hall_id']];
			}				
		}
	}

	$this->set('hall_list',$hall_list);
	
	// バーチャル口座
	$sql = "select * from a_virtual_account_list where kotei=1 and c_member_id = ".$requests['target_c_member_id'];
	$virtual_number = db_get_all($sql);
	$vn_flag = isset($vn_flag) ? $vn_flag : null;
	if(!empty($virtual_number[0]['virtual_number'])){
		$vn = $virtual_number[0]['virtual_number'];
		$vn_flag = $virtual_number[0]['flag'];
	}else{
		$vn = 0;
	}
	$this->set('vn', $vn);
	$this->set('vn_flag', $vn_flag);

	$sql = "select * from c_blacklist where c_member_id = ".$requests['target_c_member_id'];
	$result = db_get_all($sql);
	if($result){
		$this->set('blist', 1);
	}else{
		$this->set('blist', 0);
	}

        return 'success';
    }
}

?>
